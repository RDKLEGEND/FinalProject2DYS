import { LightningElement } from 'lwc';

export default class MyFirstComponent extends LightningElement {
    companyprop="RDK";
    nameprop;

    namechange(event){
        this.nameprop=event.target.value;
    }
}