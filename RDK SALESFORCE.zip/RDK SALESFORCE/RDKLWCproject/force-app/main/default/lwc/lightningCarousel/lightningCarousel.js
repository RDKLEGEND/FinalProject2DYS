import { LightningElement } from 'lwc';
import carousel1 from '@salesforce/resourceUrl/carousel1';
import LaptopImage from '@salesforce/resourceUrl/LaptopImage';
import logo from '@salesforce/resourceUrl/logo';

export default class LightningCarousel extends LightningElement {
    imgurl1=carousel1;
    imgurl2=LaptopImage;
    imgurl3=logo;
}