import { LightningElement } from 'lwc';

export default class Marquee extends LightningElement {}