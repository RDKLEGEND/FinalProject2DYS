import { LightningElement,wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation'; 
import { fireEvent } from 'c/ctsPubSub';

export default class CtsPub extends LightningElement {
@wire(CurrentPageReference)pageref;

    var1prop;
    var2prop;
    var1change(event)
    {
        this.var1prop=event.target.value;
    }
    var2change(event)
    {
        this.var2prop=event.target.value;
    }
    caloutput;
    handlechange1()
    {
        this.caloutput=parseInt(this.var1prop)+parseInt(this.var2prop);
        let newobj={
            calOut :this.caloutput
        }
        fireEvent(this.pageref,'dinesh',newobj);
    }
    handlechange2()
    {
        this.caloutput=this.var1prop-this.var2prop;
        let newobj={
            calOut :this.caloutput
        }
        fireEvent(this.pageref,'dinesh',newobj);

    }
    handlechange3()
    {
        this.caloutput=this.var1prop*this.var2prop;
        let newobj={
            calOut :this.caloutput
        }
        fireEvent(this.pageref,'dinesh',newobj);

    }
    handlechange4()
    {
        this.caloutput=this.var1prop/this.var2prop;
        let newobj={
            calOut :this.caloutput
        }
        fireEvent(this.pageref,'dinesh',newobj);

    }
}