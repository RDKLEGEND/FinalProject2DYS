import { LightningElement } from 'lwc';

export default class LifeCycleHooks extends LightningElement {

    constructor(){
        super();
        console.log('Hello I am a Constructor');
    }
    
    connectedCallback(){
        console.log('Hello I am a Constructor inside connected callback');
    }
    renderedCallback(){
        console.log('Hello I am a Constructor inside rendered callback');
    }
}