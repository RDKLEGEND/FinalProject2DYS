import { LightningElement } from 'lwc';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'

export default class Ldspracticetwo extends LightningElement {
    recordId='001dM000001t1R7QAI';
    apiName=ACCOUNT_OBJECT;
    fields=[NAME_FIELD];
    handlesuccess(event){
        const evt=new ShowToastEvent({
            title:"success",
            message:'Record ID'+event.detail.id,
            variant:success
        });
        this.dispatchEvent(evt);
    }
}