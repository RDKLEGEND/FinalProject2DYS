import { LightningElement } from 'lwc';

export default class IteratorComp extends LightningElement {
    fruits=['mango','grapes','apple','jackfruit','chikoo','pomegranate','orange','muskmelon'];

}