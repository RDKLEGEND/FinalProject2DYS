import { LightningElement,track } from 'lwc';
import LightningAlert from 'lightning/alert';

export default class ParentNotifyComponent extends LightningElement {
    //@track notificationMessage = '';

    //@track notificationVariant = '';

    async handleCustomNotification() {

        // Set notification details received from child component
        const result = await LightningAlert.open({
			label: 'Your order has been placed',
			message: 'Thankk you for ordering.Check your mail for further details.',
            theme: 'success'
		});
        //this.notificationMessage = 'button clicked';

        //this.notificationVariant = 'success';

        // Clear notification after a certain time (optional)

        /*setTimeout(() => {

            this.clearNotification();

        }, 5000); // Clear notification after 5 seconds

    }

    clearNotification() {

        // Clear notification message and variant

        this.notificationMessage = '';

        this.notificationVariant = '';
*/
}
}