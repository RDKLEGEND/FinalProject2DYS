import { LightningElement } from 'lwc';
import conCreate from '@salesforce/apex/ContactValidation.methodName';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class ContactValidationChecking extends LightningElement {
    nameprop;
    phoneprop;
    errormsg=false;
    msg='';

    namechange(event)
    {
        this.nameprop=event.target.value;
    }
    phonechange(event)
    {
        this.phoneprop=event.target.value;
    }

    createchange()
    {
        conCreate({Lname: this.nameprop,
        Phn:this.phoneprop}).then(result=>{
            if(result){
                this.errormsg=false;
            }
            else{
                this.errormsg=true;
                this.msg='Phone number InValid';
            }
        })
        .catch(error=>{
            alert('failed');
        });
    }
}