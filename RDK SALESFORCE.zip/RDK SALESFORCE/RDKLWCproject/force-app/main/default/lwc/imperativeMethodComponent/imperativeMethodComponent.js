import { LightningElement } from 'lwc';
import getAccRec from '@salesforce/apex/accRecord.methodName';


export default class ImperativeMethodComponent extends LightningElement {
    accListRec;
    handlechange(){
        getAccRec()
        .then(result=>{
            this.accListRec=result;
        })
        .catch(error=>{
            alert(error);
        });
    }

}