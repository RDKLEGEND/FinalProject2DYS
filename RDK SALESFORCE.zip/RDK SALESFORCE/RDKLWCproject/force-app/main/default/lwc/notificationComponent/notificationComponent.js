import { LightningElement,api } from 'lwc';

export default class NotificationComponent extends LightningElement {
    @api message;
    @api variant;

    get computedClass(){
        return 'notification' + this.variant;
    }
}