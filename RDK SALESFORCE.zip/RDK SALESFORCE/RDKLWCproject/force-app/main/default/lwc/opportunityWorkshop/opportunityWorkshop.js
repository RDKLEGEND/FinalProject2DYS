import { LightningElement,wire } from 'lwc';
import getConRec from '@salesforce/apex/OppConAcc.methodName';

export default class OpportunityWorkshop extends LightningElement {
    @wire(getConRec)conListRec; 
}