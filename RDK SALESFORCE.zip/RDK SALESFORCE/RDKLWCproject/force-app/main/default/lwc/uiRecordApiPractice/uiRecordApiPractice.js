import { LightningElement } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class UiRecordApiPractice extends LightningElement {
    nameprop;
    namechange(event)
    {
        this.nameprop=event.target.value;
    }
    createchange(){
        alert('hi');
    const fields={
        Name:this.nameprop
    };
    const recordInput={apiName:'Account',fields};
    
    createRecord(recordInput).then(result=>{
        console.log('Success');
        const event = new ShowToastEvent({
            title: 'Success',
            message:
                'Hello i am success',
                variant:'success'
        });
        this.dispatchEvent(event);
    }).catch(error=>{
        console.log('error');
        const event = new ShowToastEvent({
            title: 'Error',
            message:
                'Hello i am error',
                variant:'error'
        });
        this.dispatchEvent(event);
    })
    }
}