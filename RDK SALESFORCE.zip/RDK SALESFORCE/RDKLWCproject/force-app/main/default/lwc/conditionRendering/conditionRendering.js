import { LightningElement } from 'lwc';

export default class ConditionRendering extends LightningElement {
    variable = false;
    checkchange(event)
    {
        this.variable =  event.target.checked;
    }
}