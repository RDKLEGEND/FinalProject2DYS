import { LightningElement } from 'lwc';

export default class EmployeeComponent extends LightningElement {
nameprop1;
emailprop1;
ageprop1;
sample=[];
product;
buttonuse(){
let obj={dname:"rdk",age:21}
let obj2={dname:"vimal",age:23}
this.sample.push(obj);
this.sample.push(obj2);
this.product=this.sample[1].dname;
}

namechange1(event){
    let nameppp =event.target.name;
    if(nameppp == 'empname'){
        this.nameprop1 = event.target.value;

    }
    if(nameppp == 'empemail'){
        this.emailprop1 = event.target.value;

    }
    if(nameppp == 'empage'){
        this.ageprop1 = event.target.value;

    }

}

ename;
email;
emage;
onClick(){
    this.ename = this.nameprop1;
    this.email = this.emailprop1;
    this.emage = this.ageprop1;
}
}