import { LightningElement } from 'lwc';

export default class ParentComp extends LightningElement {
    nameprops;
    passname;
    empnamechange(event)
    {
        this.nameprops=event.target.value;
    }
    action()
    {
        this.passname=this.nameprops;
        let childcom=this.template.querySelector('c-child-comp');
        let senddata='GHOST';
        childcom.dinesh(senddata);
    }
}