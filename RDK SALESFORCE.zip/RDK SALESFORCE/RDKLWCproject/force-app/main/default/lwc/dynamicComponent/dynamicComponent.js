import { LightningElement,api,track, } from 'lwc';
import {createElement} from 'lwc';
export default class DynamicComponent extends LightningElement {

    @api componentName;
 
    @track componentMarkup;
 
    connectedCallback() {
 
        // Dynamically create the selected component
 
        if (this.componentName) {
 
            // Use createElement to create the component
 
            const element = createElement(this.componentName, {
 
                is: 'lightning:component'
 
            });
 
            // Add the created component to the container
 
            this.componentMarkup = element;
 
        }
 
    }
}