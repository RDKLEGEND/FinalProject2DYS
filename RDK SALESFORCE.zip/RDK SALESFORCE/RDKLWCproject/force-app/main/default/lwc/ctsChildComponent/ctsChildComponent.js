import { LightningElement } from 'lwc';

export default class CtsChildComponent extends LightningElement {
    nameprop;
    ageprop;
    namechange(event){
        this.nameprop=event.target.value;
    }
    agechange(event){
        this.ageprop=event.target.value;
    }
    handle(){
        let childeve=new CustomEvent('buttonclick',{
            detail:{
                studName:this.nameprop,
                studAge:this.ageprop
            }
        });
        this.dispatchEvent(childeve);
    }
}