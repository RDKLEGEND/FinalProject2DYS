import { LightningElement } from 'lwc';

export default class ChildLifeCycleHooks extends LightningElement {
    constructor(){
        super();
        console.log('Hello I am a child Constructor');
    }
    
    connectedCallback(){
        console.log('Hello I am a child Constructor inside connected callback');
    }
    renderedCallback(){
        console.log('Hello I am a child Constructor inside rendered callback');
    }
}