import { LightningElement,wire } from 'lwc';
import { publish, MessageContext } from 'lightning/messageService';
import mymessage from '@salesforce/messageChannel/firstChannel__c';

export default class CtsPubLms extends LightningElement {
    @wire(MessageContext)
    messageContext;
    varAprop;
    varBprop;
    namechange1(event)
    {
        this.varAprop=event.target.value;
    }
    namechange2(event)
    {
        this.varBprop=event.target.value;
    }
    calc;
    handleclick1()
    {
        this.calc=parseInt(this.varAprop)+parseInt(this.varBprop);
        const payload = { firstValue: this.calc };

        publish(this.messageContext, mymessage, payload);
    }
    handleclick2()
    {
        this.calc=this.varAprop-this.varBprop;
        const payload = { firstValue: this.calc};

        publish(this.messageContext, mymessage, payload);
    }
    handleclick3()
    {
        this.calc=this.varAprop*this.varBprop;
        const payload = { firstValue: this.calc};

        publish(this.messageContext, mymessage, payload);
    }
    handleclick4()
    {
        this.calc=this.varAprop/this.varBprop;
        const payload = { firstValue: this.calc};

        publish(this.messageContext, mymessage, payload);
    }
}