import { LightningElement } from 'lwc';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import BootstrapCSS from '@salesforce/resourceUrl/BootstrapCSS';
import BootstrapJS from '@salesforce/resourceUrl/BootstrapJS';
import JQuery from '@salesforce/resourceUrl/JQuery';
import carousel1 from '@salesforce/resourceUrl/carousel1';
import LaptopImage from '@salesforce/resourceUrl/LaptopImage';

export default class AutomatedCarousel extends LightningElement {
    imgurl1=carousel1;
    imgurl2=LaptopImage;

    connectedCallback(){
        Promise.all([
            loadStyle(this,BootstrapCSS),loadScript(this,BootstrapJS),loadScript(this,JQuery)
        ]).then(()=>{
            $('.carousel').carousel({
                 interval:2000
                });
        }).catch(error=>{

        });
    }
    // initCarousel(){
    //     $('.carousel').carousel({
    //         interval:2000, pause: 'hover', wrap:true
    //     });
    // }

}