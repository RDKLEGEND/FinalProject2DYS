import { LightningElement,api } from 'lwc';

export default class ChildComp extends LightningElement {
    @api namefromparent;
    @api dinesh(receivedata){
        alert(`Call of duty ${receivedata}`);
    }
}