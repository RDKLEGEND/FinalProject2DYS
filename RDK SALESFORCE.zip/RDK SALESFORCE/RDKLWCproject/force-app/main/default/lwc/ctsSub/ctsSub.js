import { LightningElement,wire } from 'lwc';
import { registerListener, unregisterAllListeners } from 'c/ctsPubSub'; 
import { CurrentPageReference } from 'lightning/navigation'; 


export default class CtsSub extends LightningElement {

    @wire (CurrentPageReference) pageRef;
 
     connectedCallback() {
 
        registerListener('dinesh',this.handleCallback,this);
 
    } 
    disconnectedCallback() {

        unregisterAllListeners(this);

    }
    outprop;
    handleCallback(detail){

        this.outprop=detail.calOut;
        alert('parameter from publisher :: '+detail.calOut);
 
    }

}
