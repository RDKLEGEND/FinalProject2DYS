import { LightningElement,wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import mymessage from '@salesforce/messageChannel/firstChannel__c';

export default class CtsSubLms extends LightningElement {
    @wire(MessageContext)
    messageContext;
    subscription = null;
    output;

    connectedCallback() {
        this.subscribeToMessageChannel();
    }

    subscribeToMessageChannel() {
        this.subscription = subscribe(
            this.messageContext,
            mymessage,
            (message) => this.handleMessage(message)
        );
    }

    handleMessage(message) {
        alert(`Output :: ${message.firstValue}`);
        this.output=message.firstValue;
    }

}