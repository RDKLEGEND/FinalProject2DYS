import { LightningElement,track } from 'lwc';
import getAcc from '@salesforce/apex/InsertAcc.methodName';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class AccountCreationUsingApex extends LightningElement {
    @track accName;
    
    accChange(event)
    {
            this.accName=event.target.value;
    }

    
    handleClick(){
        /*let record={
            Name:this.accName,
            Type:this.accType,
            Rating:this.accRating,
            Industry:this.accIndustry
        }
*/
        if(!this.accName)
        {
            alert('account name should not be empty');
        }
        getAcc({aName: this.accName}).then(result=>{
            const evt=new ShowToastEvent({
                title:'Success',
                message:'Account created successfully',
                variant:'success'
            })
            this.accName=NULL;
            this.dispatchEvent(evt);
        })
        .catch(error=>{
            const evt=new ShowToastEvent({
                title:'Error',
                message:'Account creation failed',
                variant:'Error'
            })
            this.dispatchEvent(evt);
        });
    }
}
