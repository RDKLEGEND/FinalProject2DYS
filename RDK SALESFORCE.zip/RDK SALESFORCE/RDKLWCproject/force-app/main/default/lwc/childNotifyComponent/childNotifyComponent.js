import { LightningElement} from 'lwc';
import { fireEvent } from 'c/ctsPubSub';

export default class ChildNotifyComponent extends LightningElement {
    handleButtonClick(){
        fireEvent(this,'customnotification',{
            title:'success',
            message:'Button clicked!',
            variant:'success'
        });
    }
}