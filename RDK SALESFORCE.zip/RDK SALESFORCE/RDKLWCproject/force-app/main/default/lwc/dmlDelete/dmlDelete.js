import { LightningElement,wire,api } from 'lwc';
import { deleteRecord } from 'lightning/uiRecordApi';
import getConRec from '@salesforce/apex/ContactDeletionHelper.methodName';
import {refreshApex} from '@salesforce/apex';
import {ShowToastEvent} from "lightning/platformShowToastEvent";

/*import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

import FIRSTNAME_FIELD from "@salesforce/schema/Contact.FirstName";
import LASTNAME_FIELD from "@salesforce/schema/Contact.LastName";
import EMAIL_FIELD from "@salesforce/schema/Contact.Email";
import PHONE_FIELD from "@salesforce/schema/Contact.Phone";
import DESCRIPTION_FIELD from "@salesforce/schema/Contact.Description";

const fields=[FIRSTNAME_FIELD,LASTNAME_FIELD,EMAIL_FIELD,PHONE_FIELD,DESCRIPTION_FIELD];
*/
export default class DmlDelete extends LightningElement {
    /*@api recordId
    @wire(getRecord, {
        recordId: "$recordId",
        fields
      })
      conList;
*/
      recordId;
      @wire(getConRec)conListRec
    viewhandler(event)
    {
        this.recordId=event.target.value;
        window.open('/' + this.recordId);
    }
    delId;
    deletehandler(event)
    {
            this.delId=event.target.value;
            deleteRecord(this.delId).then(result=>{
                const evt= new ShowToastEvent({
                    title : 'Delete',
                    message: 'Record deleted Successfully',
                    variant: 'success'
 
                });
                this.dispatchEvent(evt);
                refreshApex(this.conListRec);
            }).catch(error=>{
                const evt = new ShowToastEvent({
                    title : 'Error',
                    message: JSON.stringify(error),
                    variant:'error'
           
                });
                this.dispatchEvent(evt);
            })
    }
}