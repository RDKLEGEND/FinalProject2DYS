import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class ToastMessage extends LightningElement {
    sAction(){
        const event = new ShowToastEvent({
            title: 'Success',
            message:
                'Hello i am success',
                variant:'success'
        });
        this.dispatchEvent(event);
    }
    wAction(){
        const event = new ShowToastEvent({
            title: 'Warning',
            message:
                'Hello i am warning',
                variant:'warning'
        });
        this.dispatchEvent(event);
    }
    iAction(){
        const event = new ShowToastEvent({
            title: 'Info',
            message:
                'Hello i am info',
                variant:'info'
        });
        this.dispatchEvent(event);
    }
        eAction(){
        const event = new ShowToastEvent({
            title: 'Error',
            message:
                'Hello i am error',
                variant:'error'
        });
        this.dispatchEvent(event);
    }
}