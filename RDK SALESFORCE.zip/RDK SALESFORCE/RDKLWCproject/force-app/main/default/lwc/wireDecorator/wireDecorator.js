import { LightningElement,wire } from 'lwc';
import getConRec from '@salesforce/apex/WireDecoratorClass.methodName';

export default class WireDecorator extends LightningElement {
    conListRec;
    passName=null;
    nameProp;
    @wire(getConRec,{conName : '$passName'}) conRec({data,error}){
        if(data)
        {
            this.conListRec=data;
        }
        else if(error){
            alert('Error Alert!!!!!!!');
        }
       
    }

    namechange(event)
    {
        this.nameProp = event.target.value;
    }
    handleclick()
    {
        this.passName = this.nameProp;
    }
}