import { LightningElement } from 'lwc';

export default class CtsParentComponent extends LightningElement {
    namefromchild;
    agefromchild;
    datafromchild(event)
    {
        this.namefromchild=event.detail.studName;
        this.agefromchild=event.detail.studAge;
    }
}