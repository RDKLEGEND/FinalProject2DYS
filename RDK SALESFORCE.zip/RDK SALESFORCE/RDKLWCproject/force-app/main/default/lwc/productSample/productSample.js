import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getOrd from '@salesforce/apex/OrderCreation.methodName';
import LaptopImage from'@salesforce/resourceUrl/LaptopImage';
import LightningAlert from 'lightning/alert';

export default class ProductSample extends LightningElement {
    productName='HpVictusBook';
    cartprop=0;
    lprice=50000;
    tamnt;
    imageurl=LaptopImage;
    openOrClose=false;
    addrs='';
    addresschange(event){
        this.addrs=event.target.value;
    }
    handleclick1(){
        const event = new ShowToastEvent({
            title: 'Success',
            message:'Your product is added to cart',
            variant:'success'
        });
        this.dispatchEvent(event);
        alert('Your product added to cart');
        this.cartprop=parseInt(this.cartprop)+1;
    }
    handleclick2(){
        if(parseInt(this.cartprop)!=0){
            
            this.openOrClose=true;
        }
        else
        {
            alert('Add items in your cart before buying');
            return;
        }
    }
    confirmchange(){
        this.tamnt=parseInt(this.lprice)*parseInt(this.cartprop)
        getOrd({oname: this.productName,
            quants: this.cartprop,
            amnt: this.tamnt,
            adrs:this.addrs}).then(result=>{
            const evt=new ShowToastEvent({
                title:'Success',
                message:'Order created successfully',
                variant:'success'
            })
            this.cartprop=0;
            this.dispatchEvent(evt);
            
        })
        .catch(error=>{
            const evt=new ShowToastEvent({
                title:'Error',
                message:'Order creation failed',
                variant:'Error'
            })
            this.dispatchEvent(evt);
        });
        this.openOrClose=false;
    }
    cancelchange(){
        this.openOrClose=false;
    }
}