import { LightningElement } from 'lwc';

export default class ParentLifeCycleHooks extends LightningElement {
    constructor(){
        super();
        console.log('Hello I am a parent Constructor');
    }
    
    connectedCallback(){
        console.log('Hello I am a parent Constructor inside connected callback');
    }
    renderedCallback(){
        console.log('Hello I am a parent Constructor inside rendered callback');
    }
}