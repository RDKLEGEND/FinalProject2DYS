import { LightningElement,wire } from 'lwc';
import getAcc from '@salesforce/apex/ComboBoxAccName.methodName';

export default class ComboBox extends LightningElement {
    
    collectname=[];
    @wire(getAcc) nameprop({data,error}){
        
        let nameoptions=[];
        console.log(data);
        if(data){
        for(var i=0;i<data.length;i++)
        {
            nameoptions.push({label: data[i].Name ,value: data[i].Id });
        }
        this.collectname = nameoptions;
    }
    else if(error)
    {
        alert('Something wrong');
    }
    }
   
    value='';
    get options() {
        return this.collectname;
    }

    handleChange(event) {
        this.value = event.detail.value;
    }
}