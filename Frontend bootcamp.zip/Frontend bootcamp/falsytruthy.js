console.log('Welcome to truthyfalsy');

let dinesh;
if(dinesh){
    console.log('hi');
}
else{
    console.log('bye');
}
//passing a undefined variable returns false
let a='20';
let b=20;
if(a==b)//checks value
{
    console.log('true');
}
else{
    console.log('false');
}
if(a===b)//checks value and datatype
{
    console.log('true');
}
else{
    console.log('false');
}
