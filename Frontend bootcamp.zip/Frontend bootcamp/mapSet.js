console.log('mapSet');

let rdk=new Map();
rdk.set('native','srivilliputhur');
rdk.set('age',22);
rdk.set('skill','java');
console.log(rdk);

let cking=new Set();
cking.add(4);
cking.add(4);
cking.add(56);
cking.add(13);
console.log(cking);