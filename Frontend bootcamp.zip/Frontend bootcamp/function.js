console.log('Function');

function rdk(num1,num2,num3,num4)
{
    return (num1*num2)-num3-num4;
}

console.log(rdk(2,3,2,1));