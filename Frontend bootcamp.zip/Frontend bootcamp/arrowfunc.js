console.log(`Arrow Function`);
let dinesh=(a,b,c)=>{
    console.log('Sum of abc is :'+(a+b+c));
}
dinesh(4,5,1);
