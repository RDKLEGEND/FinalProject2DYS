console.log('stringinterpolation');

let a='dinesh ';
let b='is a ';
let c='goodboy';

let strinter=`${a}${b}${c}`;

console.log(strinter);