//import { LightningElement } from 'lwc';

//export default class Data extends LightningElement {}
export const cart=[
    {"ItemsInCart":"0"}
];